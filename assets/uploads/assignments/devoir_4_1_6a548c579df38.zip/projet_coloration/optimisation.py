"""
optimisation.py — PARTIE BONUS : Optimisation de la coloration de graphe
==========================================================================

Ce module implémente deux métaheuristiques pour améliorer la coloration
initiale obtenue par Welsh-Powell ou DSATUR :

  1. Recuit Simulé (Simulated Annealing — SA)
  2. Algorithme Génétique (Genetic Algorithm — GA)

Objectif double :
  (a) Réduire le nombre de créneaux (couleurs) utilisés.
  (b) Améliorer les contraintes souhaitées :
        - Espacer les examens d'une même filière (pas de créneaux consécutifs)
        - Équilibrer la charge par créneau
        - Placer les UE à grand effectif dans les premiers créneaux
        - Respecter les interdictions explicites de même jour

Structure :
  FonctionCout      — calcule l'énergie d'une coloration
  RecuitSimule      — implémentation complète du SA avec cooling schedule
  AlgorithmeGenetique — implémentation complète du GA
  optimiser         — fonction façade qui lance les deux et retourne le meilleur
"""

import math
import random
import time
import copy
from collections import defaultdict
from data import UES, CRENEAUX, INTERDICTIONS_MEME_JOUR, UE_PAR_ID


# ═════════════════════════════════════════════════════════════════════════════
# SECTION 1 — FONCTION DE COÛT (ÉNERGIE)
# ═════════════════════════════════════════════════════════════════════════════

class FonctionCout:
    """
    Évalue la qualité d'une coloration selon plusieurs critères pondérés.

    Une coloration est un dict : { ue_id: couleur_int (= créneau) }

    L'énergie totale est :
        E = w_hard  * violations_dures
          + w_coul  * nb_couleurs
          + w_cons  * violations_consecutives
          + w_equi  * desequilibre_charge
          + w_prio  * violations_priorite
          + w_jour  * violations_meme_jour

    - violations_dures : nb de paires adjacentes avec même couleur
      (doit être 0 dans toute solution valide, poids très élevé)
    - nb_couleurs : nombre de créneaux distincts utilisés (à minimiser)
    - violations_consecutives : UE de même filière dans des créneaux
      consécutifs (les créneaux consécutifs = IDs qui se suivent)
    - desequilibre_charge : variance du nombre d'UE par créneau
    - violations_priorite : UE à grand effectif placées tardivement
    - violations_meme_jour : interdictions dans le même créneau "jour"
    """

    # Poids (réglables)
    W_HARD  = 1000   # Pénalité très lourde pour les conflits durs
    W_COUL  =  100   # Réduire le nombre de créneaux
    W_CONS  =   20   # Éviter les créneaux consécutifs (même filière)
    W_EQUI  =   15   # Équilibrer la charge
    W_PRIO  =   10   # Priorité aux gros effectifs en premiers créneaux
    W_JOUR  =   25   # Interdictions le même jour

    def __init__(self, graphe, ues=None, creneaux=None, interdictions=None):
        self.graphe        = graphe
        self.ues           = ues or UES
        self.creneaux_data = creneaux or CRENEAUX
        self.interdictions = interdictions or INTERDICTIONS_MEME_JOUR

        # Pré-calculs pour accélération
        self.ue_par_id     = {ue["id"]: ue for ue in self.ues}
        # Créneaux "consécutifs" : même jour, positions qui se suivent
        self._construire_consecutivite()
        # Jour de chaque créneau (index)
        self._creneau_jour = {c["id"]: c["jour"] for c in self.creneaux_data}
        # Tri des UE par effectif décroissant pour la contrainte priorité
        self._ues_par_effectif = sorted(
            self.ues, key=lambda u: u["effectif"], reverse=True
        )

    def _construire_consecutivite(self):
        """
        Construit l'ensemble des paires de créneaux considérées comme
        consécutives (même jour, positions adjacentes dans la journée).
        """
        self._consecutifs = set()
        jour_creneaux = defaultdict(list)
        for c in self.creneaux_data:
            jour_creneaux[c["jour"]].append(c)
        for jour, clist in jour_creneaux.items():
            clist_sorted = sorted(clist, key=lambda c: c["pos"])
            for k in range(len(clist_sorted) - 1):
                a = clist_sorted[k]["id"]
                b = clist_sorted[k + 1]["id"]
                self._consecutifs.add((min(a, b), max(a, b)))

    def sont_consecutifs(self, c1, c2):
        return (min(c1, c2), max(c1, c2)) in self._consecutifs

    def meme_jour(self, c1, c2):
        return self._creneau_jour.get(c1) == self._creneau_jour.get(c2)

    # ─── Calcul de l'énergie totale ──────────────────────────────────────────

    def calculer(self, coloration):
        """
        Retourne le coût total d'une coloration (float).
        Plus ce score est bas, meilleure est la coloration.
        """
        hard  = self._violations_dures(coloration)
        coul  = self._nb_couleurs(coloration)
        cons  = self._violations_consecutives(coloration)
        equi  = self._desequilibre_charge(coloration)
        prio  = self._violations_priorite(coloration)
        jour  = self._violations_meme_jour(coloration)

        return (self.W_HARD * hard
                + self.W_COUL * coul
                + self.W_CONS * cons
                + self.W_EQUI * equi
                + self.W_PRIO * prio
                + self.W_JOUR * jour)

    def detail(self, coloration):
        """Retourne un dict avec le détail de chaque composante."""
        return {
            "violations_dures"       : self._violations_dures(coloration),
            "nb_couleurs"            : self._nb_couleurs(coloration),
            "violations_consecutives": self._violations_consecutives(coloration),
            "desequilibre_charge"    : round(self._desequilibre_charge(coloration), 3),
            "violations_priorite"    : self._violations_priorite(coloration),
            "violations_meme_jour"   : self._violations_meme_jour(coloration),
            "cout_total"             : round(self.calculer(coloration), 3),
        }

    # ─── Composantes individuelles ───────────────────────────────────────────

    def _violations_dures(self, col):
        """Nb de paires adjacentes avec la même couleur."""
        nb = 0
        for a in self.graphe.ids:
            for b in self.graphe.voisins(a):
                if a < b and col.get(a) == col.get(b):
                    nb += 1
        return nb

    def _nb_couleurs(self, col):
        return len(set(col.values()))

    def _violations_consecutives(self, col):
        """
        Compte les paires d'UE de la même filière dont les créneaux
        sont consécutifs (au sens de self._consecutifs).
        """
        nb = 0
        filieres = defaultdict(list)
        for ue in self.ues:
            filieres[ue["filiere"]].append(ue["id"])

        for filiere, membres in filieres.items():
            for i in range(len(membres)):
                for j in range(i + 1, len(membres)):
                    a, b = membres[i], membres[j]
                    ca, cb = col.get(a, -1), col.get(b, -1)
                    if ca != cb and self.sont_consecutifs(ca, cb):
                        nb += 1
        return nb

    def _desequilibre_charge(self, col):
        """Variance du nombre d'UE par créneau (0 = parfaitement équilibré)."""
        charges = defaultdict(int)
        for c in col.values():
            charges[c] += 1
        if not charges:
            return 0.0
        vals = list(charges.values())
        mean = sum(vals) / len(vals)
        return sum((v - mean) ** 2 for v in vals) / len(vals)

    def _violations_priorite(self, col):
        """
        Pénalise les UE à fort effectif placées dans des créneaux élevés.
        Idéalement, les top-N UE devraient occuper les N premiers créneaux.
        Score = somme(rang_creneau * rang_effectif) pour les UE hors ordre.
        """
        score = 0
        couleurs_triees = sorted(set(col.values()))
        rang_creneau = {c: i for i, c in enumerate(couleurs_triees)}

        for rang_eff, ue in enumerate(self._ues_par_effectif):
            rc = rang_creneau.get(col.get(ue["id"], 0), 0)
            # Pénalité si une UE à fort effectif est dans un créneau tardif
            if rc > rang_eff:
                score += rc - rang_eff
        return score

    def _violations_meme_jour(self, col):
        """
        Compte les paires d'interdiction placées le même jour.
        (Les créneaux ont des identifiants entiers, le "jour" est c // 4
         si on considère 4 créneaux par jour — ou via self._creneau_jour.)
        """
        nb = 0
        for a, b in self.interdictions:
            ca, cb = col.get(a, -1), col.get(b, -1)
            if ca >= 0 and cb >= 0 and self.meme_jour(ca, cb):
                nb += 1
        return nb


# ═════════════════════════════════════════════════════════════════════════════
# SECTION 2 — RECUIT SIMULÉ
# ═════════════════════════════════════════════════════════════════════════════

class RecuitSimule:
    """
    Recuit Simulé (Simulated Annealing) pour l'optimisation de la coloration.

    Principe :
      - État courant  : une coloration (dict {ue_id: couleur})
      - Énergie       : calculée par FonctionCout
      - Perturbation  : deux types de mouvements aléatoires
          MV1 — Réaffecter une UE à une couleur existante (peut créer conflit)
          MV2 — Fusionner deux couleurs en une (réduit directement nb_couleurs)
      - Acceptation   : meilleur → toujours accepté
                        moins bon → accepté avec proba exp(-ΔE / T)
      - Refroidissement : exponentiel T(k) = T0 × α^k

    Paramètres configurables :
      T0         : température initiale
      alpha      : taux de refroidissement (0 < α < 1)
      T_min      : température d'arrêt
      iterations : nb d'itérations par palier de température
      seed       : graine aléatoire pour reproductibilité
    """

    def __init__(self, graphe, fonction_cout,
                 T0=500.0, alpha=0.97, T_min=0.5,
                 iterations_par_palier=200, seed=None):
        self.graphe    = graphe
        self.fc        = fonction_cout
        self.T0        = T0
        self.alpha     = alpha
        self.T_min     = T_min
        self.iter_palier = iterations_par_palier
        self.rng       = random.Random(seed)

        # Historiques pour analyse
        self.historique_energie  = []
        self.historique_couleurs = []
        self.historique_temp     = []

    # ─── Mouvements de perturbation ──────────────────────────────────────────

    def _mv1_reaffecter(self, coloration):
        """
        Choisit une UE aléatoire et lui attribue une couleur existante
        différente de la sienne (peut créer un conflit temporaire).
        """
        new_col = dict(coloration)
        uid     = self.rng.choice(self.graphe.ids)
        couleurs_existantes = list(set(new_col.values()) - {new_col[uid]})
        if not couleurs_existantes:
            return new_col
        new_col[uid] = self.rng.choice(couleurs_existantes)
        return new_col

    def _mv2_fusionner(self, coloration):
        """
        Tente de fusionner deux couleurs c1 et c2 en c1.
        Vérifie qu'aucune arête n'existe entre un sommet de couleur c1
        et un sommet de couleur c2 (sinon la fusion est invalide).
        Retourne la coloration fusionnée si possible, sinon l'originale.
        """
        couleurs = list(set(coloration.values()))
        if len(couleurs) < 2:
            return coloration

        c1, c2 = self.rng.sample(couleurs, 2)

        # Vérifier la faisabilité : aucun conflit c1 ↔ c2
        ues_c1 = {u for u, c in coloration.items() if c == c1}
        ues_c2 = {u for u, c in coloration.items() if c == c2}

        for u1 in ues_c1:
            for u2 in ues_c2:
                if self.graphe.sont_adjacents(u1, u2):
                    return coloration   # fusion impossible

        # Fusion possible : remplacer c2 par c1
        new_col = {u: (c1 if c == c2 else c) for u, c in coloration.items()}
        # Renormaliser les couleurs (0, 1, 2, ...)
        return self._renormaliser(new_col)

    def _mv3_permuter(self, coloration):
        """
        Échange les couleurs de deux UE aléatoires.
        Utile pour améliorer les contraintes souhaitées sans changer nb_couleurs.
        """
        new_col = dict(coloration)
        ids     = self.graphe.ids
        if len(ids) < 2:
            return new_col
        u1, u2  = self.rng.sample(ids, 2)
        new_col[u1], new_col[u2] = new_col[u2], new_col[u1]
        return new_col

    @staticmethod
    def _renormaliser(coloration):
        """Remplace les couleurs par 0, 1, 2, ... en ordre croissant."""
        mapping = {}
        compteur = 0
        result = {}
        for uid, c in coloration.items():
            if c not in mapping:
                mapping[c] = compteur
                compteur += 1
            result[uid] = mapping[c]
        return result

    # ─── Boucle principale ───────────────────────────────────────────────────

    def optimiser(self, coloration_initiale, verbose=True):
        """
        Lance le recuit simulé à partir de la coloration initiale.

        Retourne :
          meilleure_coloration : dict
          energie_finale       : float
          stats                : dict de statistiques
        """
        debut        = time.perf_counter()
        courant      = self._renormaliser(dict(coloration_initiale))
        e_courant    = self.fc.calculer(courant)

        meilleur     = dict(courant)
        e_meilleur   = e_courant

        T            = self.T0
        nb_acceptes  = 0
        nb_rejetes   = 0
        nb_amelio    = 0
        palier       = 0

        if verbose:
            print("\n" + "═" * 60)
            print("  RECUIT SIMULÉ — Démarrage")
            print("═" * 60)
            print(f"  État initial   : {len(set(courant.values()))} créneaux, "
                  f"énergie = {e_courant:.1f}")
            print(f"  T0={self.T0}, α={self.alpha}, T_min={self.T_min}")
            print("-" * 60)

        while T > self.T_min:
            palier += 1

            for _ in range(self.iter_palier):
                # Choisir un mouvement aléatoire (pondéré)
                r = self.rng.random()
                if r < 0.45:
                    voisin = self._mv1_reaffecter(courant)
                elif r < 0.80:
                    voisin = self._mv2_fusionner(courant)
                else:
                    voisin = self._mv3_permuter(courant)

                e_voisin = self.fc.calculer(voisin)
                delta    = e_voisin - e_courant

                # Critère d'acceptation de Metropolis
                if delta < 0 or self.rng.random() < math.exp(-delta / T):
                    courant   = voisin
                    e_courant = e_voisin
                    nb_acceptes += 1

                    # Mise à jour du meilleur
                    if e_courant < e_meilleur:
                        meilleur   = dict(courant)
                        e_meilleur = e_courant
                        nb_amelio += 1
                else:
                    nb_rejetes += 1

            # Enregistrer l'historique
            self.historique_energie.append(e_courant)
            self.historique_couleurs.append(len(set(courant.values())))
            self.historique_temp.append(T)

            # Affichage périodique
            if verbose and palier % 20 == 0:
                print(f"  Palier {palier:>4} | T={T:>7.2f} | "
                      f"Créneaux={len(set(courant.values())):>3} | "
                      f"Énergie={e_courant:>9.1f} | "
                      f"Meilleur={len(set(meilleur.values())):>3}")

            # Refroidissement exponentiel
            T *= self.alpha

        duree = time.perf_counter() - debut

        if verbose:
            print("-" * 60)
            print(f"  ✓ Optimisation terminée en {duree:.2f}s")
            print(f"  Créneaux initiaux  : {len(set(coloration_initiale.values()))}")
            print(f"  Créneaux finaux    : {len(set(meilleur.values()))}")
            print(f"  Énergie finale     : {e_meilleur:.1f}")
            print(f"  Mouvements acceptés: {nb_acceptes} / "
                  f"{nb_acceptes + nb_rejetes}")
            print(f"  Améliorations      : {nb_amelio}")
            print("═" * 60)

        stats = {
            "methode"           : "Recuit Simulé",
            "duree_s"           : round(duree, 4),
            "paliers"           : palier,
            "nb_acceptes"       : nb_acceptes,
            "nb_rejetes"        : nb_rejetes,
            "nb_ameliorations"  : nb_amelio,
            "couleurs_initiales": len(set(coloration_initiale.values())),
            "couleurs_finales"  : len(set(meilleur.values())),
            "energie_finale"    : round(e_meilleur, 3),
        }
        return meilleur, e_meilleur, stats


# ═════════════════════════════════════════════════════════════════════════════
# SECTION 3 — ALGORITHME GÉNÉTIQUE
# ═════════════════════════════════════════════════════════════════════════════

class AlgorithmeGenetique:
    """
    Algorithme Génétique pour l'optimisation de la coloration de graphe.

    Représentation :
      Un individu (chromosome) = liste d'entiers de longueur n (une couleur
      par UE, indexée dans l'ordre de graphe.ids).

    Fitness :
      Plus le score de FonctionCout est BAS, meilleur est l'individu.
      On trie la population par fitness croissante.

    Opérateurs :
      Sélection   : tournoi (taille k) — favorise la pression sélective
      Croisement  : croisement uniforme avec réparation des conflits
      Mutation    : 3 types (réaffectation, fusion tentative, permutation)
      Élitisme    : les N meilleurs individus survivent sans modification

    Paramètres configurables :
      taille_pop    : taille de la population
      nb_generations: nombre de générations
      p_croisement  : probabilité de croisement
      p_mutation    : probabilité de mutation d'un gène
      taille_tournoi: nb participants au tournoi de sélection
      taille_elite  : nb d'élites conservées intactes
      seed          : graine aléatoire
    """

    def __init__(self, graphe, fonction_cout,
                 taille_pop=60, nb_generations=300,
                 p_croisement=0.85, p_mutation=0.15,
                 taille_tournoi=4, taille_elite=5,
                 seed=None):
        self.graphe         = graphe
        self.fc             = fonction_cout
        self.taille_pop     = taille_pop
        self.nb_gen         = nb_generations
        self.p_croisement   = p_croisement
        self.p_mutation     = p_mutation
        self.k_tournoi      = taille_tournoi
        self.taille_elite   = taille_elite
        self.rng            = random.Random(seed)
        self.n              = len(graphe.ids)
        self.ids            = graphe.ids

        # Historiques
        self.historique_meilleur = []
        self.historique_moyen    = []
        self.historique_couleurs = []

    # ─── Encodage / décodage ─────────────────────────────────────────────────

    def _encoder(self, coloration):
        """dict {ue_id: couleur} → liste de couleurs (indexée par self.ids)."""
        return [coloration[uid] for uid in self.ids]

    def _decoder(self, chromosome):
        """liste de couleurs → dict {ue_id: couleur}."""
        return {uid: chromosome[i] for i, uid in enumerate(self.ids)}

    def _fitness(self, chromosome):
        return self.fc.calculer(self._decoder(chromosome))

    # ─── Initialisation de la population ─────────────────────────────────────

    def _individu_aleatoire_valide(self, nb_couleurs_max):
        """
        Crée un individu valide par coloration gloutonne aléatoire.
        L'ordre de traitement des sommets est aléatoire.
        """
        ordre = list(self.ids)
        self.rng.shuffle(ordre)
        col = {}
        for uid in ordre:
            voisins_col = {col[v] for v in self.graphe.voisins(uid) if v in col}
            c = 0
            while c in voisins_col:
                c += 1
            # Limiter le nombre de couleurs
            if c >= nb_couleurs_max:
                # Forcer une couleur existante (peut créer un conflit acceptable)
                valides = [x for x in range(nb_couleurs_max) if x not in voisins_col]
                c = self.rng.choice(valides) if valides else c
            col[uid] = c
        return self._encoder(col)

    def _initialiser_population(self, coloration_initiale):
        """
        Génère la population initiale :
          - 1/3 à partir de la coloration initiale (+ mutations légères)
          - 1/3 colonisations aléatoires valides
          - 1/3 colonisations aléatoires avec k_max réduit (pression vers moins de couleurs)
        """
        pop = []
        base = self._encoder(coloration_initiale)
        nb_init = len(set(coloration_initiale.values()))

        # Tiers 1 : variantes de la solution initiale
        for _ in range(self.taille_pop // 3):
            ind = list(base)
            # Muter aléatoirement 10-30% des gènes
            nb_mut = max(1, int(len(ind) * self.rng.uniform(0.1, 0.3)))
            for _ in range(nb_mut):
                i = self.rng.randrange(len(ind))
                voisins_col = {
                    ind[j]
                    for j, uid in enumerate(self.ids)
                    if self.graphe.sont_adjacents(self.ids[i], uid) and j != i
                }
                valides = [c for c in range(nb_init) if c not in voisins_col]
                if valides:
                    ind[i] = self.rng.choice(valides)
            pop.append(ind)

        # Tiers 2 : colorations valides aléatoires
        for _ in range(self.taille_pop // 3):
            pop.append(self._individu_aleatoire_valide(nb_init))

        # Tiers 3 : colorations avec nb_couleurs - 1 (pression de réduction)
        for _ in range(self.taille_pop - len(pop)):
            pop.append(self._individu_aleatoire_valide(max(2, nb_init - 1)))

        return pop

    # ─── Sélection par tournoi ────────────────────────────────────────────────

    def _selection_tournoi(self, population, scores):
        """
        Sélectionne un individu par tournoi de taille k.
        Retourne l'individu avec le meilleur score parmi k candidats aléatoires.
        """
        candidats = self.rng.sample(range(len(population)), min(self.k_tournoi, len(population)))
        gagnant   = min(candidats, key=lambda i: scores[i])
        return list(population[gagnant])

    # ─── Croisement uniforme avec réparation ─────────────────────────────────

    def _croisement(self, parent1, parent2):
        """
        Croisement uniforme : chaque gène est pris aléatoirement de P1 ou P2.
        Réparation : si le gène choisi viole une contrainte dure avec un voisin
        déjà fixé, on prend l'autre parent. Si les deux violent, on choisit la
        couleur minimale valide.
        """
        if self.rng.random() > self.p_croisement:
            return list(parent1), list(parent2)

        enfant1 = [-1] * self.n
        enfant2 = [-1] * self.n

        ordre = list(range(self.n))
        self.rng.shuffle(ordre)

        def _reparer(enfant, i, c_prefer, c_autre):
            uid = self.ids[i]
            voisins_col = set()
            for j, v_id in enumerate(self.ids):
                if enfant[j] != -1 and self.graphe.sont_adjacents(uid, v_id):
                    voisins_col.add(enfant[j])
            if c_prefer not in voisins_col:
                return c_prefer
            if c_autre not in voisins_col:
                return c_autre
            c = 0
            while c in voisins_col:
                c += 1
            return c

        for i in ordre:
            if self.rng.random() < 0.5:
                enfant1[i] = _reparer(enfant1, i, parent1[i], parent2[i])
                enfant2[i] = _reparer(enfant2, i, parent2[i], parent1[i])
            else:
                enfant1[i] = _reparer(enfant1, i, parent2[i], parent1[i])
                enfant2[i] = _reparer(enfant2, i, parent1[i], parent2[i])

        return enfant1, enfant2

    # ─── Mutation ─────────────────────────────────────────────────────────────

    def _muter(self, chromosome, nb_couleurs_cibles):
        """
        3 types de mutations :
          MT1 — Réaffectation valide : choisit une UE et lui attribue une
                couleur valide différente (parmi les couleurs existantes)
          MT2 — Fusion locale : si deux couleurs c1 et c2 sont indépendantes
                dans le voisinage de l'UE, fusionner
          MT3 — Réduction : essayer d'assigner la couleur d'un voisin non-adjacent
        """
        chrom = list(chromosome)

        for i in range(self.n):
            if self.rng.random() > self.p_mutation:
                continue

            uid = self.ids[i]
            voisins_col = {
                chrom[j]
                for j, v_id in enumerate(self.ids)
                if self.graphe.sont_adjacents(uid, v_id)
            }

            r = self.rng.random()

            if r < 0.5:
                # MT1 : réaffectation valide
                couleurs_valides = [c for c in range(nb_couleurs_cibles)
                                    if c not in voisins_col]
                if couleurs_valides:
                    chrom[i] = self.rng.choice(couleurs_valides)

            elif r < 0.8:
                # MT2 : essayer une couleur existante plus petite
                couleurs_existantes = sorted(set(chrom))
                for c in couleurs_existantes:
                    if c not in voisins_col and c < chrom[i]:
                        chrom[i] = c
                        break

            else:
                # MT3 : mutation vers la couleur cible pour réduction
                target = self.rng.randint(0, max(0, nb_couleurs_cibles - 2))
                if target not in voisins_col:
                    chrom[i] = target

        return chrom

    # ─── Renormalisation ─────────────────────────────────────────────────────

    def _renormaliser(self, chromosome):
        """Remappe les couleurs de 0 à k-1 sans trous."""
        mapping = {}
        new_chrom = []
        compteur = 0
        for c in chromosome:
            if c not in mapping:
                mapping[c] = compteur
                compteur += 1
            new_chrom.append(mapping[c])
        return new_chrom

    # ─── Boucle principale ───────────────────────────────────────────────────

    def optimiser(self, coloration_initiale, verbose=True):
        """
        Lance l'algorithme génétique.

        Retourne :
          meilleur_chromosome → coloration (dict)
          energie_finale (float)
          stats (dict)
        """
        debut = time.perf_counter()

        nb_init = len(set(coloration_initiale.values()))
        nb_cibles = max(1, nb_init - 1)   # On vise à réduire d'au moins 1

        population = self._initialiser_population(coloration_initiale)
        scores     = [self._fitness(ind) for ind in population]

        meilleur_idx   = min(range(len(population)), key=lambda i: scores[i])
        meilleur_chrom = list(population[meilleur_idx])
        meilleur_score = scores[meilleur_idx]

        nb_sans_amelio = 0   # compteur de stagnation

        if verbose:
            print("\n" + "═" * 60)
            print("  ALGORITHME GÉNÉTIQUE — Démarrage")
            print("═" * 60)
            print(f"  Population     : {self.taille_pop} individus")
            print(f"  Générations    : {self.nb_gen}")
            print(f"  P(croisement)  : {self.p_croisement}")
            print(f"  P(mutation)    : {self.p_mutation}")
            print(f"  État initial   : {nb_init} créneaux, "
                  f"score={meilleur_score:.1f}")
            print("-" * 60)

        for gen in range(1, self.nb_gen + 1):
            # Tri de la population (meilleure fitness en premier)
            indices_tries = sorted(range(len(population)), key=lambda i: scores[i])
            population    = [population[i] for i in indices_tries]
            scores        = [scores[i]     for i in indices_tries]

            nouvelle_pop = []

            # Élitisme : conserver les meilleurs
            for i in range(self.taille_elite):
                nouvelle_pop.append(list(population[i]))

            # Générer le reste par sélection + croisement + mutation
            while len(nouvelle_pop) < self.taille_pop:
                p1 = self._selection_tournoi(population, scores)
                p2 = self._selection_tournoi(population, scores)
                e1, e2 = self._croisement(p1, p2)
                e1 = self._muter(self._renormaliser(e1), nb_cibles)
                e2 = self._muter(self._renormaliser(e2), nb_cibles)
                nouvelle_pop.append(e1)
                if len(nouvelle_pop) < self.taille_pop:
                    nouvelle_pop.append(e2)

            population = nouvelle_pop
            scores     = [self._fitness(ind) for ind in population]

            # Mise à jour du meilleur global
            gen_meilleur_idx  = min(range(len(population)), key=lambda i: scores[i])
            gen_meilleur_score = scores[gen_meilleur_idx]

            if gen_meilleur_score < meilleur_score:
                meilleur_score = gen_meilleur_score
                meilleur_chrom = list(population[gen_meilleur_idx])
                nb_sans_amelio = 0
                # Réduire la cible si on a moins de couleurs
                nb_actuel = len(set(meilleur_chrom))
                nb_cibles = max(1, nb_actuel - 1)
            else:
                nb_sans_amelio += 1

            # Historiques
            scores_valides = [s for s in scores if s < float("inf")]
            moy = sum(scores_valides) / len(scores_valides) if scores_valides else 0
            self.historique_meilleur.append(meilleur_score)
            self.historique_moyen.append(moy)
            self.historique_couleurs.append(len(set(meilleur_chrom)))

            # Affichage périodique
            if verbose and gen % 30 == 0:
                print(f"  Gén. {gen:>4} | Créneaux={len(set(meilleur_chrom)):>3} | "
                      f"Score={meilleur_score:>9.1f} | Moy={moy:>9.1f} | "
                      f"Stag={nb_sans_amelio:>4}")

            # Arrêt anticipé si stagnation prolongée
            if nb_sans_amelio > 80:
                if verbose:
                    print(f"  ⚡ Arrêt anticipé — stagnation depuis {nb_sans_amelio} générations")
                break

        duree = time.perf_counter() - debut
        meilleure_col = self._decoder(self._renormaliser(meilleur_chrom))

        if verbose:
            print("-" * 60)
            print(f"  ✓ Optimisation terminée en {duree:.2f}s")
            print(f"  Créneaux initiaux : {nb_init}")
            print(f"  Créneaux finaux   : {len(set(meilleur_chrom))}")
            print(f"  Score final       : {meilleur_score:.1f}")
            print("═" * 60)

        stats = {
            "methode"           : "Algorithme Génétique",
            "duree_s"           : round(duree, 4),
            "generations"       : gen,
            "taille_pop"        : self.taille_pop,
            "couleurs_initiales": nb_init,
            "couleurs_finales"  : len(set(meilleur_chrom)),
            "energie_finale"    : round(meilleur_score, 3),
        }
        return meilleure_col, meilleur_score, stats


# ═════════════════════════════════════════════════════════════════════════════
# SECTION 4 — VISUALISATION DES COURBES DE CONVERGENCE
# ═════════════════════════════════════════════════════════════════════════════

def tracer_convergences(sa=None, ga=None, fichier="convergences.png"):
    """
    Trace les courbes de convergence du RS et/ou de l'AG sur une figure.
    sa : instance RecuitSimule (après optimisation)
    ga : instance AlgorithmeGenetique (après optimisation)
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    fig.suptitle("Courbes de Convergence — Optimisation", fontsize=14, fontweight="bold")

    # ── Panneau gauche : Énergie ──────────────────────────────────────────────
    ax1 = axes[0]
    ax1.set_title("Évolution de l'Énergie", fontsize=12)
    if sa and sa.historique_energie:
        ax1.plot(sa.historique_energie, color="#E63946", linewidth=1.5,
                 label="Recuit Simulé", alpha=0.8)
    if ga and ga.historique_meilleur:
        ax1.plot(ga.historique_meilleur, color="#457B9D", linewidth=1.5,
                 label="Algo. Génétique", alpha=0.8)
        ax1.plot(ga.historique_moyen, color="#A8DADC", linewidth=1,
                 label="AG — Moyenne pop.", alpha=0.6, linestyle="--")
    ax1.set_xlabel("Itérations / Générations")
    ax1.set_ylabel("Énergie (coût)")
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # ── Panneau droit : Nombre de créneaux ───────────────────────────────────
    ax2 = axes[1]
    ax2.set_title("Évolution du Nombre de Créneaux", fontsize=12)
    if sa and sa.historique_couleurs:
        ax2.plot(sa.historique_couleurs, color="#E63946", linewidth=2,
                 label="Recuit Simulé", alpha=0.8)
    if ga and ga.historique_couleurs:
        ax2.plot(ga.historique_couleurs, color="#457B9D", linewidth=2,
                 label="Algo. Génétique", alpha=0.8)
    ax2.set_xlabel("Itérations / Générations")
    ax2.set_ylabel("Nombre de créneaux")
    ax2.yaxis.get_major_locator().set_params(integer=True)
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(fichier, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [✓] Courbes sauvegardées → {fichier}")
    return fichier


# ═════════════════════════════════════════════════════════════════════════════
# SECTION 5 — FONCTION FAÇADE : optimiser()
# ═════════════════════════════════════════════════════════════════════════════

def optimiser(graphe, coloration_initiale, ues=None, creneaux=None,
              interdictions=None, seed=42, verbose=True):
    """
    Lance les deux méthodes (RS + AG) et retourne la meilleure coloration.

    Retourne :
      meilleure_coloration : dict {ue_id: creneau_int}
      rapport              : dict avec toutes les statistiques
    """
    fc = FonctionCout(graphe, ues=ues, creneaux=creneaux,
                      interdictions=interdictions)

    # ── Recuit Simulé ─────────────────────────────────────────────────────────
    rs = RecuitSimule(graphe, fc,
                      T0=600.0, alpha=0.975, T_min=0.3,
                      iterations_par_palier=250, seed=seed)
    col_sa, score_sa, stats_sa = rs.optimiser(coloration_initiale, verbose=verbose)

    # ── Algorithme Génétique ──────────────────────────────────────────────────
    ag = AlgorithmeGenetique(graphe, fc,
                             taille_pop=80, nb_generations=400,
                             p_croisement=0.85, p_mutation=0.12,
                             taille_tournoi=5, taille_elite=6,
                             seed=seed + 1)
    col_ga, score_ga, stats_ga = ag.optimiser(coloration_initiale, verbose=verbose)

    # ── Comparaison ───────────────────────────────────────────────────────────
    if verbose:
        print("\n" + "═" * 60)
        print("  COMPARAISON RS vs AG")
        print("═" * 60)
        for label, stats, col in [("Recuit Simulé", stats_sa, col_sa),
                                   ("Algo. Génétique", stats_ga, col_ga)]:
            detail = fc.detail(col)
            print(f"\n  [{label}]")
            print(f"    Créneaux       : {stats['couleurs_finales']}")
            print(f"    Durée          : {stats['duree_s']} s")
            print(f"    Score total    : {detail['cout_total']}")
            print(f"    - Conflits durs: {detail['violations_dures']}")
            print(f"    - Consécutifs  : {detail['violations_consecutives']}")
            print(f"    - Déséquilibre : {detail['desequilibre_charge']}")
            print(f"    - Prio effectif: {detail['violations_priorite']}")
            print(f"    - Même jour    : {detail['violations_meme_jour']}")

    # Choisir la meilleure (moins de créneaux, puis moins d'énergie)
    nb_sa = len(set(col_sa.values()))
    nb_ga = len(set(col_ga.values()))

    if nb_ga < nb_sa or (nb_ga == nb_sa and score_ga < score_sa):
        meilleure, methode = col_ga, "Algorithme Génétique"
        meilleur_score = score_ga
    else:
        meilleure, methode = col_sa, "Recuit Simulé"
        meilleur_score = score_sa

    if verbose:
        print(f"\n  ✅ Meilleure méthode : {methode}")
        print(f"     Créneaux finaux  : {len(set(meilleure.values()))}")
        print(f"     (initiau x       : {len(set(coloration_initiale.values()))})")
        print("═" * 60)

    # Tracer les courbes de convergence
    tracer_convergences(sa=rs, ga=ag, fichier="convergences.png")

    rapport = {
        "coloration_initiale"     : len(set(coloration_initiale.values())),
        "meilleure_methode"       : methode,
        "couleurs_finales"        : len(set(meilleure.values())),
        "score_final"             : round(meilleur_score, 3),
        "gain_creneaux"           : len(set(coloration_initiale.values()))
                                    - len(set(meilleure.values())),
        "stats_recuit_simule"     : stats_sa,
        "stats_algo_genetique"    : stats_ga,
        "detail_cout_final"       : fc.detail(meilleure),
    }
    return meilleure, rapport
