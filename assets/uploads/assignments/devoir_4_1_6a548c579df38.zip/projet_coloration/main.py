"""
main.py — Point d'entrée principal du projet
Orchestre toutes les parties : graphe → coloration → affectation → optimisation
"""

import os, sys

# ─── Imports ─────────────────────────────────────────────────────────────────
from data           import (UES, SALLES, CRENEAUX, INTERDICTIONS_MEME_JOUR,
                             generer_inscriptions)
from graphe         import GrapheConflits
from coloration     import welsh_powell, dsatur, comparer_algorithmes, verifier_coloration
from affectation    import affecter_salles, afficher_planning
from optimisation   import optimiser, FonctionCout
from planning       import exporter_csv, rapport_audit


def separateur(titre=""):
    print("\n" + "▓" * 65)
    if titre:
        print(f"  {titre}")
        print("▓" * 65)


def main():
    os.makedirs("sorties", exist_ok=True)

    # ═══════════════════════════════════════════════════════════════
    # PARTIE 1 — Construction du graphe
    # ═══════════════════════════════════════════════════════════════
    separateur("PARTIE 1 — Construction du graphe de conflits")

    inscriptions = generer_inscriptions(seed=42)
    graphe = GrapheConflits(inscriptions,
                             interdictions=INTERDICTIONS_MEME_JOUR,
                             ues=UES)
    graphe.afficher_stats()
    graphe.visualiser(fichier="sorties/graphe_conflits.png")

    # ═══════════════════════════════════════════════════════════════
    # PARTIE 2 — Algorithmes de coloration
    # ═══════════════════════════════════════════════════════════════
    separateur("PARTIE 2 — Algorithmes de coloration (Welsh-Powell & DSATUR)")

    col_wp, nb_wp, t_wp = welsh_powell(graphe)
    col_ds, nb_ds, t_ds = dsatur(graphe)

    meilleure_initiale, nb_init = comparer_algorithmes(graphe)

    # Visualisation avec la meilleure coloration initiale
    graphe.visualiser(coloration=meilleure_initiale,
                      titre=f"Coloration initiale — {nb_init} créneaux",
                      fichier="sorties/graphe_colore_initial.png")

    # ═══════════════════════════════════════════════════════════════
    # PARTIE 3 — Affectation des salles
    # ═══════════════════════════════════════════════════════════════
    separateur("PARTIE 3 — Affectation des salles et planning initial")

    planning_init, erreurs = affecter_salles(meilleure_initiale, UES)
    if erreurs:
        print("\n  ⚠  Alertes affectation :")
        for e in erreurs:
            print(f"     {e}")

    afficher_planning(planning_init, creneaux=CRENEAUX)
    exporter_csv(planning_init, creneaux=CRENEAUX,
                 fichier="sorties/planning_initial.csv")
    rapport_audit(planning_init, graphe, meilleure_initiale, creneaux=CRENEAUX)

    # ═══════════════════════════════════════════════════════════════
    # PARTIE BONUS — Optimisation (Recuit Simulé + Algorithme Génétique)
    # ═══════════════════════════════════════════════════════════════
    separateur("PARTIE BONUS — Optimisation (RS + AG)")

    coloration_optimisee, rapport_optim = optimiser(
        graphe,
        meilleure_initiale,
        ues=UES,
        creneaux=CRENEAUX,
        interdictions=INTERDICTIONS_MEME_JOUR,
        seed=42,
        verbose=True,
    )

    # Vérification de la validité après optimisation
    valide, conflits = verifier_coloration(graphe, coloration_optimisee)
    if valide:
        print("\n  ✅ Coloration optimisée VALIDE (aucun conflit dur)")
    else:
        print(f"\n  ⚠  Coloration optimisée contient {len(conflits)} conflit(s)")

    # Planning final après optimisation
    separateur("Planning final après optimisation")
    planning_opt, erreurs_opt = affecter_salles(coloration_optimisee, UES)
    afficher_planning(planning_opt, creneaux=CRENEAUX)
    exporter_csv(planning_opt, creneaux=CRENEAUX,
                 fichier="sorties/planning_optimise.csv")
    rapport_audit(planning_opt, graphe, coloration_optimisee, creneaux=CRENEAUX)

    # Visualisation finale
    graphe.visualiser(
        coloration=coloration_optimisee,
        titre=f"Coloration optimisée — "
              f"{len(set(coloration_optimisee.values()))} créneaux",
        fichier="sorties/graphe_colore_optimise.png",
    )

    # ── Résumé final ──────────────────────────────────────────────
    separateur("RÉSUMÉ FINAL")
    print(f"  Créneaux initiaux  (greedy)      : {rapport_optim['coloration_initiale']}")
    print(f"  Créneaux après optimisation      : {rapport_optim['couleurs_finales']}")
    print(f"  Gain                             : -{rapport_optim['gain_creneaux']} créneau(x)")
    print(f"  Meilleure méthode                : {rapport_optim['meilleure_methode']}")
    print()
    print("  Détail du coût final :")
    for k, v in rapport_optim["detail_cout_final"].items():
        print(f"    {k:<30} : {v}")
    print()
    print("  Fichiers générés dans ./sorties/ :")
    for f in sorted(os.listdir("sorties")):
        print(f"    ✔  {f}")
    print("▓" * 65)


if __name__ == "__main__":
    main()
