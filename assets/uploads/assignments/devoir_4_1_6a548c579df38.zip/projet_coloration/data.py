"""
data.py — Données de test pour le projet de planification d'examens
Contient les UEs, étudiants, salles, surveillants et contraintes explicites
"""

import random

# ─── UNITÉS D'ENSEIGNEMENT ────────────────────────────────────────────────────
# Chaque UE a : id, nom, filière, effectif, besoin de labo, surveillant
UES = [
    {"id": "UE01", "nom": "Mathématiques 1",        "filiere": "INF", "effectif": 45, "labo": False, "surveillant": "Prof_Dupont"},
    {"id": "UE02", "nom": "Algorithmique",           "filiere": "INF", "effectif": 50, "labo": False, "surveillant": "Prof_Martin"},
    {"id": "UE03", "nom": "Programmation Python",   "filiere": "INF", "effectif": 48, "labo": True,  "surveillant": "Prof_Leroy"},
    {"id": "UE04", "nom": "Architecture Réseaux",   "filiere": "INF", "effectif": 35, "labo": False, "surveillant": "Prof_Dubois"},
    {"id": "UE05", "nom": "Base de Données",        "filiere": "INF", "effectif": 40, "labo": True,  "surveillant": "Prof_Leroy"},
    {"id": "UE06", "nom": "Physique Appliquée",     "filiere": "ELE", "effectif": 30, "labo": False, "surveillant": "Prof_Bernard"},
    {"id": "UE07", "nom": "Électronique Num.",      "filiere": "ELE", "effectif": 28, "labo": True,  "surveillant": "Prof_Simon"},
    {"id": "UE08", "nom": "Probabilités",           "filiere": "MAT", "effectif": 55, "labo": False, "surveillant": "Prof_Dupont"},
    {"id": "UE09", "nom": "Systèmes d'Exploitation","filiere": "INF", "effectif": 42, "labo": False, "surveillant": "Prof_Martin"},
    {"id": "UE10", "nom": "Compilation",            "filiere": "INF", "effectif": 38, "labo": False, "surveillant": "Prof_Dubois"},
    {"id": "UE11", "nom": "Génie Logiciel",         "filiere": "INF", "effectif": 33, "labo": False, "surveillant": "Prof_Leroy"},
    {"id": "UE12", "nom": "Analyse Numérique",      "filiere": "MAT", "effectif": 25, "labo": True,  "surveillant": "Prof_Bernard"},
    {"id": "UE13", "nom": "Réseaux Avancés",        "filiere": "INF", "effectif": 30, "labo": False, "surveillant": "Prof_Simon"},
    {"id": "UE14", "nom": "Traitement du Signal",   "filiere": "ELE", "effectif": 22, "labo": True,  "surveillant": "Prof_Bernard"},
    {"id": "UE15", "nom": "Intelligence Artificielle","filiere": "INF","effectif": 60, "labo": True,  "surveillant": "Prof_Martin"},
]

# ─── SALLES ───────────────────────────────────────────────────────────────────
# Chaque salle a : id, nom, capacité, type (labo ou standard)
SALLES = [
    {"id": "S01", "nom": "Amphi A",     "capacite": 100, "labo": False},
    {"id": "S02", "nom": "Salle B",     "capacite": 60,  "labo": False},
    {"id": "S03", "nom": "Salle C",     "capacite": 50,  "labo": False},
    {"id": "S04", "nom": "Salle D",     "capacite": 40,  "labo": False},
    {"id": "S05", "nom": "Labo Info 1", "capacite": 30,  "labo": True},
    {"id": "S06", "nom": "Labo Info 2", "capacite": 25,  "labo": True},
    {"id": "S07", "nom": "Labo Élec",  "capacite": 20,  "labo": True},
]

# ─── CRÉNEAUX HORAIRES ────────────────────────────────────────────────────────
# Chaque créneau : index, jour (1=Lundi..5=Vendredi), position dans la journée
CRENEAUX = [
    {"id": 0, "label": "Lundi 08h-10h",     "jour": 1, "pos": 0},
    {"id": 1, "label": "Lundi 10h-12h",     "jour": 1, "pos": 1},
    {"id": 2, "label": "Lundi 14h-16h",     "jour": 1, "pos": 2},
    {"id": 3, "label": "Lundi 16h-18h",     "jour": 1, "pos": 3},
    {"id": 4, "label": "Mardi 08h-10h",     "jour": 2, "pos": 0},
    {"id": 5, "label": "Mardi 10h-12h",     "jour": 2, "pos": 1},
    {"id": 6, "label": "Mardi 14h-16h",     "jour": 2, "pos": 2},
    {"id": 7, "label": "Mardi 16h-18h",     "jour": 2, "pos": 3},
    {"id": 8, "label": "Mercredi 08h-10h",  "jour": 3, "pos": 0},
    {"id": 9, "label": "Mercredi 10h-12h",  "jour": 3, "pos": 1},
    {"id":10, "label": "Mercredi 14h-16h",  "jour": 3, "pos": 2},
    {"id":11, "label": "Mercredi 16h-18h",  "jour": 3, "pos": 3},
]

# ─── INSCRIPTIONS ÉTUDIANTS ───────────────────────────────────────────────────
# Génération déterministe : chaque étudiant est inscrit à plusieurs UE

def generer_inscriptions(seed=42):
    """
    Retourne un dict : { "UE01": {etudiant_ids...}, "UE02": {...}, ... }
    Les étudiants partagés entre deux UE créent un conflit (arête dans le graphe).

    Modèle réaliste : chaque étudiant est dans une filière principale et
    choisit ses UE en grande majorité dans sa filière (+ 0-1 UE hors filière).
    Cela produit un graphe SPARSE (non complet) adapté à l'optimisation.
    """
    random.seed(seed)
    inscriptions = {ue["id"]: set() for ue in UES}

    # Groupes d'UE par filière
    filieres = {}
    for ue in UES:
        filieres.setdefault(ue["filiere"], []).append(ue["id"])

    # Répartition des étudiants : ~60 INF, ~35 ELE, ~25 MAT
    effectifs_filieres = {"INF": 60, "ELE": 35, "MAT": 25}
    etu_id = 1

    for filiere, nb_etus in effectifs_filieres.items():
        ues_filiere = filieres[filiere]
        ues_autres  = [ue["id"] for ue in UES if ue["filiere"] != filiere]

        for _ in range(nb_etus):
            # 2-4 UE de la filière principale (adaptée à la taille du groupe)
            nb_max = min(4, len(ues_filiere))
            nb_min = min(2, nb_max)
            nb_filiere = random.randint(nb_min, nb_max)
            choisies = set(random.sample(ues_filiere, nb_filiere))

            # 0-1 UE d'une autre filière (20% de chance)
            if ues_autres and random.random() < 0.20:
                choisies.add(random.choice(ues_autres))

            for ue_id in choisies:
                inscriptions[ue_id].add(etu_id)
            etu_id += 1

    return inscriptions

# ─── INTERDICTIONS EXPLICITES ─────────────────────────────────────────────────
# Paires d'UE qui ne doivent PAS avoir lieu le même jour (contrainte souhaitée)
INTERDICTIONS_MEME_JOUR = [
    ("UE02", "UE09"),   # Algorithmique + Systèmes : même prof principal (Martin)
    ("UE03", "UE05"),   # Python + BDD : même surveillant + même public
    ("UE08", "UE01"),   # Proba + Math1 : même public Math
    ("UE13", "UE04"),   # Réseaux Avancés + Architecture Réseaux : même thème
]

# ─── ACCÈS RAPIDE ─────────────────────────────────────────────────────────────
UE_IDS     = [ue["id"] for ue in UES]
UE_PAR_ID  = {ue["id"]: ue for ue in UES}
SALLE_PAR_ID = {s["id"]: s for s in SALLES}
