"""
planning.py — Génération du planning CSV et rapport d'audit (Partie 3)
"""

import csv
import os
from data import CRENEAUX, UE_PAR_ID


def exporter_csv(planning, creneaux=None, fichier="planning_examens.csv"):
    """
    Exporte le planning au format créneau × salle en CSV.
    Cellule : "UE_ID (effectif)" ou vide.
    """
    creneaux = creneaux or CRENEAUX
    salles_utilisees = sorted(set(
        info["salle"]["id"] for info in planning.values() if info["salle"]
    ))

    # Index : {(creneau, salle_id): info_ue}
    grille = {}
    for uid, info in planning.items():
        if info["salle"]:
            grille[(info["creneau"], info["salle"]["id"])] = info

    with open(fichier, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        # En-tête
        writer.writerow(["Créneau"] + salles_utilisees)
        # Lignes
        for c in creneaux:
            cid   = c["id"]
            label = c["label"]
            row   = [label]
            for sid in salles_utilisees:
                info = grille.get((cid, sid))
                if info:
                    row.append(f"{info['ue']['id']} ({info['ue']['effectif']} etu.)")
                else:
                    row.append("")
            writer.writerow(row)

    print(f"  [✓] Planning CSV exporté → {fichier}")
    return fichier


def rapport_audit(planning, graphe, coloration, creneaux=None):
    """
    Vérifie toutes les contraintes et affiche un rapport d'audit complet.
    """
    creneaux = creneaux or CRENEAUX
    from coloration import verifier_coloration

    print("\n" + "═" * 65)
    print("  RAPPORT D'AUDIT — VÉRIFICATION DES CONTRAINTES")
    print("═" * 65)

    # ── Contrainte 1 : pas de conflits durs ───────────────────────────────────
    valide, conflits = verifier_coloration(graphe, coloration)
    statut = "✅ OK" if valide else f"❌ {len(conflits)} conflit(s)"
    print(f"\n  [C1] Un étudiant ≤ 1 examen / créneau           : {statut}")
    for a, b, c in conflits[:5]:
        print(f"       → Conflit : {a} et {b} dans le créneau {c}")

    # ── Contrainte 2 : unicité salle par créneau ─────────────────────────────
    occ = {}
    double_salles = []
    for uid, info in planning.items():
        if info["salle"]:
            key = (info["creneau"], info["salle"]["id"])
            if key in occ:
                double_salles.append((uid, occ[key], info["creneau"]))
            else:
                occ[key] = uid
    statut = "✅ OK" if not double_salles else f"❌ {len(double_salles)} doublon(s)"
    print(f"  [C2] Unicité de salle par créneau                : {statut}")

    # ── Contrainte 3 : capacité respectée ────────────────────────────────────
    depassements = []
    for uid, info in planning.items():
        if info["salle"] and info["ue"]["effectif"] > info["salle"]["capacite"]:
            depassements.append((uid, info["ue"]["effectif"], info["salle"]["capacite"]))
    statut = "✅ OK" if not depassements else f"❌ {len(depassements)} dépassement(s)"
    print(f"  [C3] Capacité salle respectée                    : {statut}")
    for uid, eff, cap in depassements[:3]:
        print(f"       → {uid} : {eff} étudiants > capacité {cap}")

    # ── Contrainte 4 : type de salle ─────────────────────────────────────────
    mauvais_type = []
    for uid, info in planning.items():
        if info["salle"]:
            if info["ue"]["labo"] and not info["salle"]["labo"]:
                mauvais_type.append((uid, "labo requis, salle standard"))
    statut = "✅ OK" if not mauvais_type else f"⚠  {len(mauvais_type)} inadéquation(s)"
    print(f"  [C4] Type de salle (labo/standard) adéquat       : {statut}")

    # ── Contrainte 5 : salles assignées à toutes les UE ──────────────────────
    sans_salle = [uid for uid, info in planning.items() if not info["salle"]]
    statut = "✅ OK" if not sans_salle else f"❌ {len(sans_salle)} UE sans salle"
    print(f"  [C5] Toutes les UE ont une salle                 : {statut}")

    # ── Résumé ────────────────────────────────────────────────────────────────
    nb_ues     = len(planning)
    nb_creneaux = len(set(info["creneau"] for info in planning.values()))
    charge     = {}
    for info in planning.values():
        c = info["creneau"]
        charge[c] = charge.get(c, 0) + 1

    print(f"\n  Résumé du planning :")
    print(f"    UEs planifiées    : {nb_ues}")
    print(f"    Créneaux utilisés : {nb_creneaux}")
    print(f"    UEs par créneau   : min={min(charge.values())}, "
          f"max={max(charge.values())}, "
          f"moy={sum(charge.values())/len(charge):.1f}")
    print("═" * 65)
    return {
        "conflits_durs"    : len(conflits),
        "doubles_salles"   : len(double_salles),
        "depassements_cap" : len(depassements),
        "mauvais_type"     : len(mauvais_type),
        "sans_salle"       : len(sans_salle),
        "nb_creneaux"      : nb_creneaux,
        "nb_ues"           : nb_ues,
    }
