"""
affectation.py — Affectation des salles après coloration (Partie 3)
Respecte : capacité, type de salle (labo/standard), unicité par créneau.
"""

from data import SALLES, UE_PAR_ID, CRENEAUX


# ═════════════════════════════════════════════════════════════════════════════
# Affectation des salles
# ═════════════════════════════════════════════════════════════════════════════

def affecter_salles(coloration, ues):
    """
    Pour chaque (UE, créneau) issu de la coloration, trouve une salle :
      1. Du bon type (labo si UE.labo == True)
      2. De capacité suffisante (salle.capacite >= UE.effectif)
      3. Non déjà occupée dans ce créneau

    Paramètres :
      coloration : dict {ue_id: creneau_int}
      ues        : liste des UEs (avec id, effectif, labo)

    Retourne :
      planning   : dict {ue_id: {"creneau": int, "salle": dict|None}}
      erreurs    : liste de messages d'erreur (salles non trouvées)
    """
    # Salles triées par capacité croissante (optimise l'usage)
    salles_triees = sorted(SALLES, key=lambda s: s["capacite"])

    # Occupation : {creneau_int: set(salle_id)}
    occupation = {}

    planning = {}
    erreurs  = []
    ue_par_id = {ue["id"]: ue for ue in ues}

    # Traiter les UE par effectif décroissant (priorité aux grands groupes)
    ues_triees = sorted(ues, key=lambda ue: ue["effectif"], reverse=True)

    for ue in ues_triees:
        uid     = ue["id"]
        creneau = coloration[uid]
        occupation.setdefault(creneau, set())

        salle_choisie = None
        for salle in salles_triees:
            # Critère 1 : type
            if ue["labo"] and not salle["labo"]:
                continue
            if not ue["labo"] and salle["labo"]:
                continue          # ne pas gaspiller un labo pour une salle std
            # Critère 2 : capacité
            if salle["capacite"] < ue["effectif"]:
                continue
            # Critère 3 : disponibilité
            if salle["id"] in occupation[creneau]:
                continue

            salle_choisie = salle
            break

        # Si aucune salle standard convient, tenter n'importe quel type
        if salle_choisie is None:
            for salle in salles_triees:
                if salle["capacite"] >= ue["effectif"] \
                   and salle["id"] not in occupation[creneau]:
                    salle_choisie = salle
                    break

        if salle_choisie:
            occupation[creneau].add(salle_choisie["id"])
        else:
            erreurs.append(
                f"[ERREUR] Aucune salle disponible pour {uid} "
                f"(effectif={ue['effectif']}, labo={ue['labo']}, créneau={creneau})"
            )

        planning[uid] = {
            "creneau"    : creneau,
            "salle"      : salle_choisie,
            "ue"         : ue,
        }

    return planning, erreurs


def afficher_planning(planning, creneaux=None):
    """Affiche le planning sous forme de tableau lisible."""
    creneaux = creneaux or CRENEAUX
    creneau_labels = {c["id"]: c["label"] for c in creneaux}

    # Regrouper par créneau
    par_creneau = {}
    for uid, info in planning.items():
        c = info["creneau"]
        par_creneau.setdefault(c, []).append(info)

    print("\n" + "=" * 80)
    print("  PLANNING DES EXAMENS")
    print("=" * 80)
    print(f"  {'Créneau':<22}  {'UE':<6}  {'Intitulé':<26}  {'Salle':<12}  {'Eff.':>4}")
    print("-" * 80)

    for c in sorted(par_creneau):
        label = creneau_labels.get(c, f"Créneau {c}")
        for info in sorted(par_creneau[c], key=lambda x: x["ue"]["id"]):
            salle_nom = info["salle"]["nom"] if info["salle"] else "⚠ MANQUANTE"
            print(f"  {label:<22}  {info['ue']['id']:<6}  "
                  f"{info['ue']['nom']:<26}  {salle_nom:<12}  "
                  f"{info['ue']['effectif']:>4}")
        print("-" * 80)
    print("=" * 80)
