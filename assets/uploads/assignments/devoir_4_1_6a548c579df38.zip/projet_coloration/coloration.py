"""
coloration.py — Algorithmes de coloration de graphe (Parties 1 & 2)
Welsh-Powell et DSATUR, avec comparaison de performance.
"""

import time
from graphe import GrapheConflits


# ═════════════════════════════════════════════════════════════════════════════
# Utilitaires communs
# ═════════════════════════════════════════════════════════════════════════════

def _couleur_minimale(voisins_colores):
    """Retourne le plus petit entier ≥ 0 absent du set de couleurs voisines."""
    c = 0
    while c in voisins_colores:
        c += 1
    return c

def verifier_coloration(graphe, coloration):
    """
    Vérifie qu'aucune paire de sommets adjacents ne partage la même couleur.
    Retourne (True, []) si valide, sinon (False, [conflits]).
    """
    conflits = []
    for a in graphe.ids:
        for b in graphe.voisins(a):
            if a < b and coloration.get(a) == coloration.get(b):
                conflits.append((a, b, coloration[a]))
    return (len(conflits) == 0), conflits


# ═════════════════════════════════════════════════════════════════════════════
# Algorithme Welsh-Powell
# ═════════════════════════════════════════════════════════════════════════════

def welsh_powell(graphe):
    """
    Algorithme glouton Welsh-Powell :
      1. Trier les sommets par degré décroissant.
      2. Pour chaque sommet (dans l'ordre), assigner la plus petite couleur
         non utilisée par ses voisins déjà colorés.

    Retourne : (coloration: dict, nb_couleurs: int, temps_ms: float)
    """
    debut = time.perf_counter()

    # Étape 1 : tri par degré décroissant
    ordre = sorted(graphe.ids, key=lambda uid: graphe.degre(uid), reverse=True)

    coloration = {}
    for uid in ordre:
        couleurs_voisines = {coloration[v] for v in graphe.voisins(uid)
                             if v in coloration}
        coloration[uid] = _couleur_minimale(couleurs_voisines)

    nb_couleurs = len(set(coloration.values()))
    duree = (time.perf_counter() - debut) * 1000

    return coloration, nb_couleurs, duree


# ═════════════════════════════════════════════════════════════════════════════
# Algorithme DSATUR
# ═════════════════════════════════════════════════════════════════════════════

def dsatur(graphe):
    """
    Algorithme DSATUR (Degree of SATURation) :
      À chaque étape, choisir le sommet non coloré avec la plus grande
      saturation (nb de couleurs distinctes dans son voisinage).
      En cas d'égalité, choisir celui de plus haut degré.

    Retourne : (coloration: dict, nb_couleurs: int, temps_ms: float)
    """
    debut = time.perf_counter()

    non_colores = set(graphe.ids)
    coloration  = {}
    saturation  = {uid: 0 for uid in graphe.ids}      # nb couleurs voisines
    couleurs_voisines = {uid: set() for uid in graphe.ids}

    while non_colores:
        # Choisir le sommet de saturation maximale (puis degré max)
        uid = max(non_colores,
                  key=lambda u: (saturation[u], graphe.degre(u)))

        # Attribuer la plus petite couleur disponible
        c = _couleur_minimale(couleurs_voisines[uid])
        coloration[uid] = c
        non_colores.discard(uid)

        # Mettre à jour la saturation des voisins non colorés
        for voisin in graphe.voisins(uid):
            if voisin in non_colores:
                avant = len(couleurs_voisines[voisin])
                couleurs_voisines[voisin].add(c)
                if len(couleurs_voisines[voisin]) > avant:
                    saturation[voisin] += 1

    nb_couleurs = len(set(coloration.values()))
    duree = (time.perf_counter() - debut) * 1000

    return coloration, nb_couleurs, duree


# ═════════════════════════════════════════════════════════════════════════════
# Comparaison des deux algorithmes
# ═════════════════════════════════════════════════════════════════════════════

def comparer_algorithmes(graphe):
    """Affiche un tableau comparatif Welsh-Powell vs DSATUR."""
    col_wp,   nb_wp,   t_wp  = welsh_powell(graphe)
    col_ds,   nb_ds,   t_ds  = dsatur(graphe)

    ok_wp, _  = verifier_coloration(graphe, col_wp)
    ok_ds, _  = verifier_coloration(graphe, col_ds)

    print("\n" + "=" * 56)
    print("  COMPARAISON DES ALGORITHMES DE COLORATION")
    print("=" * 56)
    print(f"  {'Algorithme':<18}  {'Créneaux':>8}  {'Temps (ms)':>10}  {'Valide':>7}")
    print("-" * 56)
    print(f"  {'Welsh-Powell':<18}  {nb_wp:>8}  {t_wp:>10.4f}  {'Oui' if ok_wp else 'NON':>7}")
    print(f"  {'DSATUR':<18}  {nb_ds:>8}  {t_ds:>10.4f}  {'Oui' if ok_ds else 'NON':>7}")
    print("=" * 56)

    meilleur_col = col_ds if nb_ds <= nb_wp else col_wp
    meilleur_nb  = min(nb_ds, nb_wp)
    print(f"\n  ➜ Meilleure coloration initiale : {meilleur_nb} créneaux")
    return meilleur_col, meilleur_nb


# ═════════════════════════════════════════════════════════════════════════════
# Point d'entrée autonome
# ═════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    from data import generer_inscriptions, INTERDICTIONS_MEME_JOUR
    inscriptions = generer_inscriptions()
    g = GrapheConflits(inscriptions, interdictions=INTERDICTIONS_MEME_JOUR)
    meilleure, nb = comparer_algorithmes(g)
    print("\n  Coloration DSATUR :", meilleure)
