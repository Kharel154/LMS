"""
graphe.py — Construction et visualisation du graphe de conflits
Partie 1 du projet : matrice d'adjacence + liste d'adjacence + visualisation
"""

import networkx as nx
import matplotlib
matplotlib.use("Agg")          # backend sans fenêtre (serveur / CI)
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from data import UES, UE_IDS, generer_inscriptions


# ═════════════════════════════════════════════════════════════════════════════
# 1.  Construction du graphe de conflits
# ═════════════════════════════════════════════════════════════════════════════

class GrapheConflits:
    """
    Représente le graphe dont :
      - chaque sommet  = une UE
      - chaque arête   = conflit (au moins un étudiant en commun,
                          ou même surveillant, ou interdiction explicite)
    Deux représentations : matrice d'adjacence + liste d'adjacence.
    """

    def __init__(self, inscriptions, interdictions=None, ues=None):
        self.ues         = ues if ues else UES
        self.n           = len(self.ues)
        self.ids         = [ue["id"] for ue in self.ues]
        self.idx         = {uid: i for i, uid in enumerate(self.ids)}
        self.inscriptions = inscriptions              # {ue_id: {etudiant_ids}}
        self.interdictions = interdictions or []      # [(ue_a, ue_b)]

        # Structures de données
        self.matrice     = [[0] * self.n for _ in range(self.n)]
        self.liste       = {uid: set() for uid in self.ids}

        self._construire()

    # ─── Construction ────────────────────────────────────────────────────────

    def _construire(self):
        """Ajoute les arêtes selon 3 sources de conflits."""
        # Source 1 : étudiants en commun
        for i, a in enumerate(self.ids):
            for j in range(i + 1, self.n):
                b = self.ids[j]
                if self.inscriptions[a] & self.inscriptions[b]:
                    self._ajouter_arete(a, b)

        # Source 2 : même surveillant
        surveillants = {}
        for ue in self.ues:
            s = ue["surveillant"]
            surveillants.setdefault(s, []).append(ue["id"])
        for groupe in surveillants.values():
            for i in range(len(groupe)):
                for j in range(i + 1, len(groupe)):
                    self._ajouter_arete(groupe[i], groupe[j])

        # Source 3 : interdictions explicites
        for a, b in self.interdictions:
            if a in self.idx and b in self.idx:
                self._ajouter_arete(a, b)

    def _ajouter_arete(self, a, b):
        i, j = self.idx[a], self.idx[b]
        if not self.matrice[i][j]:           # éviter les doublons
            self.matrice[i][j] = 1
            self.matrice[j][i] = 1
            self.liste[a].add(b)
            self.liste[b].add(a)

    # ─── Statistiques ────────────────────────────────────────────────────────

    def nb_sommets(self):
        return self.n

    def nb_aretes(self):
        return sum(self.matrice[i][j]
                   for i in range(self.n)
                   for j in range(i + 1, self.n))

    def degre(self, uid):
        return len(self.liste[uid])

    def voisins(self, uid):
        return self.liste[uid]

    def sont_adjacents(self, a, b):
        return self.matrice[self.idx[a]][self.idx[b]] == 1

    def afficher_stats(self):
        print("=" * 55)
        print("  STATISTIQUES DU GRAPHE DE CONFLITS")
        print("=" * 55)
        print(f"  Sommets (UEs)  : {self.nb_sommets()}")
        print(f"  Arêtes         : {self.nb_aretes()}")
        print("-" * 55)
        print(f"  {'UE':<6}  {'Nom':<28}  {'Degré':>5}")
        print("-" * 55)
        for ue in self.ues:
            uid = ue["id"]
            print(f"  {uid:<6}  {ue['nom']:<28}  {self.degre(uid):>5}")
        print("=" * 55)

    # ─── Visualisation ───────────────────────────────────────────────────────

    def visualiser(self, coloration=None, titre="Graphe de Conflits",
                   fichier="graphe_conflits.png"):
        """
        Génère une image PNG du graphe.
        coloration : dict {ue_id: couleur_int} pour colorer les nœuds.
        """
        G = nx.Graph()
        G.add_nodes_from(self.ids)
        for a in self.ids:
            for b in self.liste[a]:
                if a < b:
                    G.add_edge(a, b)

        plt.figure(figsize=(14, 10))
        pos = nx.spring_layout(G, seed=7, k=2.2)

        # Couleurs des nœuds
        palette = [
            "#E63946","#457B9D","#2A9D8F","#E9C46A","#F4A261",
            "#A8DADC","#6A4C93","#F77F00","#588157","#BC6C25",
            "#219EBC","#FF6B6B","#C77DFF",
        ]
        if coloration:
            node_colors = [palette[coloration.get(n, 0) % len(palette)]
                           for n in G.nodes()]
        else:
            node_colors = ["#ADB5BD"] * len(G.nodes())

        labels = {uid: f"{uid}\n({self.degre(uid)})" for uid in self.ids}
        nx.draw_networkx_edges(G, pos, alpha=0.4, edge_color="#6C757D", width=1.5)
        nx.draw_networkx_nodes(G, pos, node_color=node_colors,
                               node_size=900, alpha=0.95)
        nx.draw_networkx_labels(G, pos, labels=labels, font_size=7,
                                font_weight="bold", font_color="white")

        if coloration:
            nb_couleurs = len(set(coloration.values()))
            legende = [mpatches.Patch(color=palette[c % len(palette)],
                                      label=f"Créneau {c+1}")
                       for c in range(nb_couleurs)]
            plt.legend(handles=legende, loc="upper left",
                       fontsize=8, title="Créneaux")

        plt.title(titre, fontsize=14, fontweight="bold", pad=15)
        plt.axis("off")
        plt.tight_layout()
        plt.savefig(fichier, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"  [✓] Graphe sauvegardé → {fichier}")
        return fichier


# ═════════════════════════════════════════════════════════════════════════════
# Point d'entrée autonome
# ═════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    from data import INTERDICTIONS_MEME_JOUR
    inscriptions = generer_inscriptions()
    g = GrapheConflits(inscriptions, interdictions=INTERDICTIONS_MEME_JOUR)
    g.afficher_stats()
    g.visualiser(fichier="graphe_conflits.png")
