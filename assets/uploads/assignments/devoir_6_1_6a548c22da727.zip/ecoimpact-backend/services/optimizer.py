"""
Module 2 : Algorithme d'Optimisation (PuLP).

Problème de type "sac à dos" en variables continues bornées [0,1] (fraction d'adoption
de l'écogeste) :

    Minimiser   Σ (Ei × xi)                      [effort global]
    Sous contrainte de : Σ (Impacti × xi) ≥ Objectif_Réduction   [kg CO2e à réduire]
                          0 ≤ xi ≤ 1

Chaque xi représente le degré d'application de l'écogeste i (0 = non appliqué,
1 = appliqué pleinement, valeurs intermédiaires = application partielle, ex: réduire
la clim de 1h sur les 2h disponibles -> xi = 0.5).
"""
import pulp

from schemas import HabitsInput, ActionResult
from services.calculator import (
    FACTEUR_VOITURE_SOLO_KM,
    FACTEUR_CLIM_HEURE,
    FACTEUR_GROUPE_ELECTROGENE_HEURE,
    FACTEUR_DECHET_KG_NON_TRIE,
)


def _generer_ecogestes(habits: HabitsInput) -> list[dict]:
    """
    Construit dynamiquement la liste des écogestes disponibles pour CET utilisateur,
    avec leur potentiel de réduction CO2e (mensuel) et leur pénibilité (1=facile, 5=difficile).
    Le potentiel est borné par les habitudes réellement déclarées (on ne propose pas de
    réduire une activité que l'utilisateur ne pratique pas).
    """
    gestes = []

    if habits.km_voiture_solo_semaine > 0:
        gestes.append({
            "nom": "Remplacer la voiture solo par du covoiturage / taxi-moto",
            "potentiel_co2": habits.km_voiture_solo_semaine * FACTEUR_VOITURE_SOLO_KM * 4.345 * 0.6,
            "effort": 3,
        })

    if habits.heures_climatisation_jour > 0:
        gestes.append({
            "nom": "Réduire la climatisation de 2h par jour",
            "potentiel_co2": min(2, habits.heures_climatisation_jour) * FACTEUR_CLIM_HEURE * 30,
            "effort": 2,
        })

    if habits.heures_groupe_electrogene_semaine > 0:
        gestes.append({
            "nom": "Réduire l'usage du groupe électrogène de 3h/semaine",
            "potentiel_co2": min(3, habits.heures_groupe_electrogene_semaine) * FACTEUR_GROUPE_ELECTROGENE_HEURE * 4.345,
            "effort": 4,
        })

    if habits.kg_dechets_semaine > 0 and not habits.dechets_tries:
        gestes.append({
            "nom": "Mettre en place le tri des déchets ménagers",
            "potentiel_co2": habits.kg_dechets_semaine * (FACTEUR_DECHET_KG_NON_TRIE - 0.180) * 4.345,
            "effort": 1,
        })

    if habits.kwh_electricite_mois > 0:
        gestes.append({
            "nom": "Optimiser la consommation électrique (veille, éclairage LED)",
            "potentiel_co2": habits.kwh_electricite_mois * 0.15 * 0.210,
            "effort": 2,
        })

    return gestes


def optimiser_plan(
    habits: HabitsInput, total_co2_actuel: float, objectif_reduction_pct: float
) -> tuple[str, float, list[ActionResult]]:
    """
    Résout le programme linéaire et retourne (statut, reduction_obtenue_pct, actions).
    """
    gestes = _generer_ecogestes(habits)

    if not gestes:
        return "AUCUNE_ACTION_DISPONIBLE", 0.0, []

    objectif_kg = total_co2_actuel * (objectif_reduction_pct / 100)

    prob = pulp.LpProblem("EcoImpact_Minimisation_Effort", pulp.LpMinimize)

    # Variables de décision : fraction d'adoption de chaque geste [0,1]
    x = [
        pulp.LpVariable(f"x_{i}", lowBound=0, upBound=1, cat="Continuous")
        for i in range(len(gestes))
    ]

    # Fonction objectif : minimiser l'effort total pondéré
    prob += pulp.lpSum(gestes[i]["effort"] * x[i] for i in range(len(gestes)))

    # Contrainte : atteindre l'objectif de réduction en kg CO2e
    prob += pulp.lpSum(gestes[i]["potentiel_co2"] * x[i] for i in range(len(gestes))) >= objectif_kg

    prob.solve(pulp.PULP_CBC_CMD(msg=False))

    statut = pulp.LpStatus[prob.status]

    actions: list[ActionResult] = []
    reduction_totale = 0.0

    for i, geste in enumerate(gestes):
        quantite = round(x[i].value() or 0.0, 3)
        if quantite > 0.01:  # ignorer les actions non significatives
            reduction = round(geste["potentiel_co2"] * quantite, 2)
            reduction_totale += reduction
            actions.append(
                ActionResult(
                    action_name=geste["nom"],
                    reduction_estimated=reduction,
                    effort_score=geste["effort"],
                    quantite_appliquee=quantite,
                )
            )

    reduction_pct = round((reduction_totale / total_co2_actuel) * 100, 1) if total_co2_actuel > 0 else 0.0

    if statut != "Optimal":
        statut_label = "OBJECTIF_PARTIELLEMENT_ATTEIGNABLE"
    else:
        statut_label = "OPTIMAL"

    return statut_label, reduction_pct, actions
