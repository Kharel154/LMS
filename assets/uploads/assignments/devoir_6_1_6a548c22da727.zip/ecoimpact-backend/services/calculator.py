"""
Module 1 : Moteur de Calcul d'Impact Contextualisé.

Émissions = Donnée_Activité × Facteur_Émission

Facteurs d'émission adaptés au contexte camerounais :
- Réseau électrique Sud (interconnecté) largement hydroélectrique -> faible kgCO2/kWh
- Forte prépondérance des groupes électrogènes thermiques (diesel)
- Transport dominé par taxi/moto-taxi partagés plutôt que voiture solo
- Gestion informelle des déchets (brûlage fréquent en l'absence de tri)
"""
from schemas import HabitsInput, ScoreBreakdown

# --- Facteurs d'émission (kg CO2e par unité) ---
FACTEUR_VOITURE_SOLO_KM = 0.192        # kg CO2e / km (essence, usage urbain)
FACTEUR_TAXI_MOTO_KM = 0.085           # kg CO2e / km (partagé -> ratio par passager)
FACTEUR_TRANSPORT_COMMUN_KM = 0.060    # kg CO2e / km

FACTEUR_ELEC_RESEAU_KWH = 0.210        # kg CO2e / kWh (mix hydro/thermique Sud Cameroun)
FACTEUR_CLIM_HEURE = 0.450             # kg CO2e / heure de clim (consommation moyenne unité split)
FACTEUR_GROUPE_ELECTROGENE_HEURE = 1.800  # kg CO2e / heure (diesel, groupe domestique moyen)

FACTEUR_DECHET_KG_NON_TRIE = 0.450     # kg CO2e / kg (brûlage informel / décharge)
FACTEUR_DECHET_KG_TRIE = 0.180         # kg CO2e / kg (réduction via tri/recyclage)

# Pondération de normalisation pour le score sur 100 (calibrage interne)
PLAFOND_TRANSPORT = 80.0   # kg CO2e/semaine considéré comme "score transport max"
PLAFOND_ENERGIE = 120.0    # kg CO2e/semaine
PLAFOND_DECHET = 25.0      # kg CO2e/semaine


def _normaliser(valeur: float, plafond: float) -> float:
    """Convertit une quantité de CO2 en score 0-100 (borné)."""
    if plafond <= 0:
        return 0.0
    score = (valeur / plafond) * 100
    return round(min(max(score, 0), 100), 1)


def calculer_impact(habits: HabitsInput) -> ScoreBreakdown:
    """Calcule les sous-scores et le total CO2e mensuel à partir des habitudes saisies."""

    # --- Transport (hebdomadaire) ---
    co2_transport = (
        habits.km_voiture_solo_semaine * FACTEUR_VOITURE_SOLO_KM
        + habits.km_taxi_moto_semaine * FACTEUR_TAXI_MOTO_KM
        + habits.km_transport_commun_semaine * FACTEUR_TRANSPORT_COMMUN_KM
    )

    # --- Énergie (mensuel pour l'élec, hebdo pour clim/groupe -> ramené au mois) ---
    co2_elec = habits.kwh_electricite_mois * FACTEUR_ELEC_RESEAU_KWH
    co2_clim_mois = habits.heures_climatisation_jour * FACTEUR_CLIM_HEURE * 30
    co2_groupe_mois = habits.heures_groupe_electrogene_semaine * FACTEUR_GROUPE_ELECTROGENE_HEURE * 4.345
    co2_energie = co2_elec + co2_clim_mois + co2_groupe_mois

    # --- Déchets (hebdomadaire -> mensuel) ---
    facteur_dechet = FACTEUR_DECHET_KG_TRIE if habits.dechets_tries else FACTEUR_DECHET_KG_NON_TRIE
    co2_dechet_mois = habits.kg_dechets_semaine * facteur_dechet * 4.345

    total_co2 = round(
        (co2_transport * 4.345) + co2_energie + co2_dechet_mois, 2
    )

    return ScoreBreakdown(
        transport_score=_normaliser(co2_transport, PLAFOND_TRANSPORT),
        energy_score=_normaliser((co2_clim_mois + co2_groupe_mois) / 4.345 + habits.kwh_electricite_mois / 30 * FACTEUR_ELEC_RESEAU_KWH, PLAFOND_ENERGIE),
        waste_score=_normaliser(habits.kg_dechets_semaine * facteur_dechet, PLAFOND_DECHET),
        total_co2=total_co2,
    )
