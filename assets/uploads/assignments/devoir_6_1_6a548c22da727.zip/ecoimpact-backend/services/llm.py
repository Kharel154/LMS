"""
Module 3 : Couche NLP & Agent Conversationnel (API Gemini).

Encapsule le score brut + le plan d'action calculé par PuLP dans un prompt système
sécurisé, avec consigne de vulgarisation pédagogique en français, ancrée dans le
contexte camerounais.
"""
import os
import httpx

from schemas import ChatRequest

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
GEMINI_URL = (
    f"https://generativelanguage.googleapis.com/v1beta/models/"
    f"{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}"
)

SYSTEM_PROMPT = """Tu es l'assistant pédagogique d'EcoImpact AI, une plateforme camerounaise \
de pilotage de l'empreinte environnementale citoyenne.

Consignes strictes :
- Réponds UNIQUEMENT en français.
- Adopte un ton chaleureux, encourageant, jamais culpabilisant ni anxiogène.
- Intègre des réalités et expressions locales camerounaises quand c'est pertinent \
(groupe électrogène, moto-taxi, climatiseur, quartier) pour ancrer le discours.
- Explique le score et le plan d'action de façon simple, concrète, actionnable.
- Termine toujours par une note motivante et un encouragement à passer à l'action.
- Ne donne jamais de conseils médicaux, financiers ou hors du périmètre environnemental.
"""


def _construire_prompt_utilisateur(payload: ChatRequest) -> str:
    score = payload.score
    lignes_actions = "\n".join(
        f"- {a.action_name} (réduction estimée: {a.reduction_estimated} kg CO2e, "
        f"pénibilité: {a.effort_score}/5)"
        for a in payload.actions
    )

    contexte = f"""Voici le bilan de l'utilisateur :
- Score transport : {score.transport_score}/100
- Score énergie : {score.energy_score}/100
- Score déchets : {score.waste_score}/100
- Empreinte totale : {score.total_co2} kg CO2e / mois

Plan d'action optimal calculé (effort minimal pour l'objectif visé) :
{lignes_actions if lignes_actions else "Aucune action prioritaire identifiée."}
"""

    if payload.user_message:
        contexte += f"\nQuestion de l'utilisateur : {payload.user_message}\n"
        contexte += "Réponds à sa question en t'appuyant sur son bilan ci-dessus."
    else:
        contexte += "\nRédige une synthèse pédagogique motivante de ce bilan et de ce plan."

    return contexte


async def generer_synthese(payload: ChatRequest) -> str:
    """Appelle l'API Gemini et retourne la synthèse pédagogique en français."""
    if not GEMINI_API_KEY:
        return (
            "Configuration manquante : la clé GEMINI_API_KEY n'est pas définie côté serveur. "
            "Contactez l'administrateur de la plateforme."
        )

    user_prompt = _construire_prompt_utilisateur(payload)

    body = {
        "contents": [{"role": "user", "parts": [{"text": user_prompt}]}],
        "systemInstruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "generationConfig": {"temperature": 0.7, "maxOutputTokens": 600},
    }

    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.post(GEMINI_URL, json=body)
            response.raise_for_status()
            data = response.json()
            return data["candidates"][0]["content"]["parts"][0]["text"]
    except httpx.HTTPStatusError as e:
        return f"Erreur lors de l'appel à l'assistant IA (HTTP {e.response.status_code})."
    except (KeyError, IndexError):
        return "L'assistant IA n'a pas pu générer de réponse exploitable. Veuillez réessayer."
    except httpx.RequestError:
        return "Impossible de contacter l'assistant IA pour le moment. Veuillez réessayer plus tard."
