"""
Point d'entrée de l'API EcoImpact AI.
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database.postgres import init_db
from routes import auth, score, optimize, chat


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(
    title="EcoImpact AI — API",
    description="Plateforme intelligente de pilotage et d'optimisation de l'empreinte "
                "environnementale citoyenne au Cameroun.",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # à restreindre au domaine du frontend Next.js en production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(score.router)
app.include_router(optimize.router)
app.include_router(chat.router)


@app.get("/", tags=["Santé"])
def health_check():
    return {"status": "ok", "service": "EcoImpact AI Backend", "version": "2.0.0"}
