"""
Modèles SQLAlchemy : tables `assessments` et `recommendations`.
"""
from sqlalchemy import Column, Integer, Float, String, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database.postgres import Base


class Assessment(Base):
    __tablename__ = "assessments"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    transport_score = Column(Float, nullable=False, default=0.0)
    energy_score = Column(Float, nullable=False, default=0.0)
    waste_score = Column(Float, nullable=False, default=0.0)
    total_co2 = Column(Float, nullable=False, default=0.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    owner = relationship("User", back_populates="assessments")
    recommendations = relationship(
        "Recommendation", back_populates="assessment", cascade="all, delete-orphan"
    )


class Recommendation(Base):
    __tablename__ = "recommendations"

    id = Column(Integer, primary_key=True, index=True)
    assessment_id = Column(Integer, ForeignKey("assessments.id"), nullable=False)
    action_name = Column(String(255), nullable=False)
    reduction_estimated = Column(Float, nullable=False, default=0.0)
    effort_score = Column(Integer, nullable=False, default=1)  # 1 à 5
    is_adopted = Column(Boolean, default=False)

    assessment = relationship("Assessment", back_populates="recommendations")
