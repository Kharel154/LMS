"""
Schémas Pydantic (validation des requêtes / sérialisation des réponses).
"""
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, EmailStr, Field


# ---------- AUTH ----------

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    email: EmailStr
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---------- ASSESSMENT (Module Calculateur) ----------

class HabitsInput(BaseModel):
    """Saisie brute des habitudes de consommation (Étape 1 du parcours)."""
    # Transport
    km_voiture_solo_semaine: float = 0
    km_taxi_moto_semaine: float = 0
    km_transport_commun_semaine: float = 0

    # Énergie / logement
    kwh_electricite_mois: float = 0
    heures_climatisation_jour: float = 0
    heures_groupe_electrogene_semaine: float = 0

    # Déchets
    kg_dechets_semaine: float = 0
    dechets_tries: bool = False


class ScoreBreakdown(BaseModel):
    transport_score: float
    energy_score: float
    waste_score: float
    total_co2: float  # kg CO2e / mois


class AssessmentOut(BaseModel):
    id: int
    user_id: int
    transport_score: float
    energy_score: float
    waste_score: float
    total_co2: float
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- OPTIMISATION (Module 2) ----------

class OptimizeRequest(BaseModel):
    assessment_id: int
    objectif_reduction_pct: float = Field(30.0, ge=1, le=100)
    habits: HabitsInput  # nécessaire pour connaître les bornes des variables


class ActionResult(BaseModel):
    action_name: str
    reduction_estimated: float  # en kg CO2e
    effort_score: int  # 1 à 5
    quantite_appliquee: float


class OptimizeResponse(BaseModel):
    assessment_id: int
    objectif_reduction_pct: float
    reduction_obtenue_pct: float
    statut: str
    actions: List[ActionResult]


# ---------- CHAT / LLM (Module 3) ----------

class ChatRequest(BaseModel):
    assessment_id: int
    score: ScoreBreakdown
    actions: List[ActionResult]
    user_message: Optional[str] = None  # question libre de l'utilisateur (suivi)


class ChatResponse(BaseModel):
    reply: str
