"""
Configuration de la connexion PostgreSQL (SQLAlchemy Engine + Session).
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://ecoimpact_user:ecoimpact_pass@localhost:5432/ecoimpact_db"
)

# pool_pre_ping évite les connexions mortes (utile sur Render/Railway)
engine = create_engine(DATABASE_URL, pool_pre_ping=True)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """Dependency FastAPI : fournit une session DB et la ferme après usage."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Crée toutes les tables si elles n'existent pas (à appeler au démarrage)."""
    from models import user, assessment  # noqa: F401 (enregistre les modèles)
    Base.metadata.create_all(bind=engine)
