"""
Route déclenchant le moteur d'optimisation PuLP (Étape 4 du parcours).
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database.postgres import get_db
from models.user import User
from models.assessment import Assessment, Recommendation
from schemas import OptimizeRequest, OptimizeResponse
from security import get_current_user
from services.optimizer import optimiser_plan

router = APIRouter(prefix="/optimize", tags=["Optimisation"])


@router.post("/", response_model=OptimizeResponse)
def lancer_optimisation(
    payload: OptimizeRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    assessment = (
        db.query(Assessment)
        .filter(Assessment.id == payload.assessment_id, Assessment.user_id == current_user.id)
        .first()
    )
    if not assessment:
        raise HTTPException(status_code=404, detail="Bilan introuvable.")

    statut, reduction_pct, actions = optimiser_plan(
        habits=payload.habits,
        total_co2_actuel=assessment.total_co2,
        objectif_reduction_pct=payload.objectif_reduction_pct,
    )

    # Persiste le plan d'action généré (remplace les anciennes recommandations du bilan)
    db.query(Recommendation).filter(Recommendation.assessment_id == assessment.id).delete()
    for action in actions:
        db.add(
            Recommendation(
                assessment_id=assessment.id,
                action_name=action.action_name,
                reduction_estimated=action.reduction_estimated,
                effort_score=action.effort_score,
                is_adopted=False,
            )
        )
    db.commit()

    return OptimizeResponse(
        assessment_id=assessment.id,
        objectif_reduction_pct=payload.objectif_reduction_pct,
        reduction_obtenue_pct=reduction_pct,
        statut=statut,
        actions=actions,
    )
