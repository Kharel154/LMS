"""
Route proxy vers l'API Gemini pour la vulgarisation pédagogique (Étape 5 du parcours).
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from database.postgres import get_db
from models.user import User
from security import get_current_user
from schemas import ChatRequest, ChatResponse
from services.llm import generer_synthese

router = APIRouter(prefix="/chat", tags=["Assistant IA"])


@router.post("/", response_model=ChatResponse)
async def discuter_avec_assistant(
    payload: ChatRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Envoie le bilan + plan d'action (et une éventuelle question libre de l'utilisateur)
    à Gemini, encapsulés dans un prompt système sécurisé, et retourne la synthèse en français.
    """
    reply = await generer_synthese(payload)
    return ChatResponse(reply=reply)
