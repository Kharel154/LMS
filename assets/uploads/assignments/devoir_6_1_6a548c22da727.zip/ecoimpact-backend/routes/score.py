"""
Routes CRUD pour les évaluations (bilans carbone) — Étapes 1 & 2 du parcours.
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database.postgres import get_db
from models.user import User
from models.assessment import Assessment
from schemas import HabitsInput, AssessmentOut
from security import get_current_user
from services.calculator import calculer_impact

router = APIRouter(prefix="/score", tags=["Évaluations"])


@router.post("/", response_model=AssessmentOut, status_code=status.HTTP_201_CREATED)
def creer_evaluation(
    habits: HabitsInput,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Calcule l'empreinte à partir des habitudes saisies et persiste le bilan."""
    breakdown = calculer_impact(habits)

    assessment = Assessment(
        user_id=current_user.id,
        transport_score=breakdown.transport_score,
        energy_score=breakdown.energy_score,
        waste_score=breakdown.waste_score,
        total_co2=breakdown.total_co2,
    )
    db.add(assessment)
    db.commit()
    db.refresh(assessment)
    return assessment


@router.get("/", response_model=List[AssessmentOut])
def lister_evaluations(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Historique complet des bilans de l'utilisateur connecté."""
    return (
        db.query(Assessment)
        .filter(Assessment.user_id == current_user.id)
        .order_by(Assessment.created_at.desc())
        .all()
    )


@router.get("/{assessment_id}", response_model=AssessmentOut)
def obtenir_evaluation(
    assessment_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    assessment = (
        db.query(Assessment)
        .filter(Assessment.id == assessment_id, Assessment.user_id == current_user.id)
        .first()
    )
    if not assessment:
        raise HTTPException(status_code=404, detail="Bilan introuvable.")
    return assessment


@router.delete("/{assessment_id}", status_code=status.HTTP_204_NO_CONTENT)
def supprimer_evaluation(
    assessment_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    assessment = (
        db.query(Assessment)
        .filter(Assessment.id == assessment_id, Assessment.user_id == current_user.id)
        .first()
    )
    if not assessment:
        raise HTTPException(status_code=404, detail="Bilan introuvable.")
    db.delete(assessment)
    db.commit()
    return None
